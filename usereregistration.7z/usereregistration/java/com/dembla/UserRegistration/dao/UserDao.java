package com.dembla.UserRegistration.dao;

import com.dembla.UserRegistration.model.User;

public interface UserDao {

	void saveUser(User user) ; 
}
