package com.dembla.UserRegistration.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Java based configuration
 * 
 * @author ramesh Fadatare
 *
 */
public class HibernateUtil {
	private static final SessionFactory sessionFactory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		try {
			
			Configuration configuration = new Configuration().configure();

			return configuration.buildSessionFactory(
					new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry());
			
		} catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

}
