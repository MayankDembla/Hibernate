package com.mayank.lobbytransport.service;

import java.util.List;

import com.mayank.lobbytransport.model.Vehicle;

public interface VehicleServices {
	
	void registerNewVehicle(Vehicle vehicle) ; 
	
	Vehicle getVehicleByName(String name) ; 
	
	List<Vehicle> getregVehicles() ; 

}
