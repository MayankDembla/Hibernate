package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.dao.CompanyDao;
import com.mayank.lobbytransport.dao.CompanyDaoImpl;
import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.model.Company;

public class CompanyServiceImpl implements CompanyServices {

	CompanyDao dao ; 
	PersistDao pdao ; 
	
	
	public CompanyServiceImpl() {
         dao = new CompanyDaoImpl() ;
         pdao = new PersistDaoImpl() ; 
	}
	
	@Override
	public void addCompany(Company company) {
		pdao.register(company);
	}
	
	@Override
	public void modifyCompany(Company company) {
		dao.modifyCompany(company);
	}

	@Override
	public void deleteCompany(int uin) {
          dao.deleteCompany(uin);
	}

}
