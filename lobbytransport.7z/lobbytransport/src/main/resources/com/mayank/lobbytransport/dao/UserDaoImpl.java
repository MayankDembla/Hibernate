package com.mayank.lobbytransport.dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import com.mayank.lobbytransport.model.User;
import com.mayank.lobbytransport.util.HibernateUtil;

public class UserDaoImpl implements UserDao {

	private Session session;

	private Criteria criteria;

	public UserDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		criteria = session.createCriteria(User.class);
	}

	@Override
	public User getUserByName(String name, String password) {
		User user = null;
		criteria.add(Restrictions.eq("name", name)); 
		criteria.add(Restrictions.eq("password", password)); 
		List<User> listuser = criteria.list();

		if (!listuser.isEmpty())
			user = listuser.get(0);

		return user;
	}

	@Override
	public List<User> getregisteredUsers() {

		return criteria.list();
	}

	@Override
	public boolean isValidUser(String name, String password) {

		criteria.add(Restrictions.eq("name", name));
		criteria.add(Restrictions.eq("password", password));

		if (criteria.list().get(0) == null)
			return false;

		return true;

	}

}
