package com.mayank.lobbytransport.builder;

import com.mayank.lobbytransport.model.Driver;

public class DriverBuilder {

	public int driverid;
	public String name;
	public String address ; 
	public String city ; 
	public String state ; 
	public long mobileNumber;
	
	DriverBuilder(int driverId)
	{
		 this.driverid = driverId ; 
	}
	
	public DriverBuilder name(String name) {
		this.name = name ; 
        return this ; 		
	}
	
	public DriverBuilder address(String address) { 
		this.address = address ; 
		return this ; 
	}
	
	public DriverBuilder city(String city) { 
		this.city = city ; 
		return this ; 
	}
	
	public DriverBuilder state(String state) { 
		this.state = state ; 
		return this ; 
	}
	
	public DriverBuilder mobile(String number) { 
		this.mobileNumber = Long.valueOf(number) ; 
		return this ; 
	}
	
	public Driver build()
	{
		 Driver driver = new Driver(this) ; 
		 validateDriver(driver);
		 return driver ; 
	}
	
	private void validateDriver(Driver driver) { 
		// this is for validation of Driver .. 
	}
	
}
