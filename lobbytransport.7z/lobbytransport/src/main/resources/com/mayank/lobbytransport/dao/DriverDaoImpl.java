package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Driver;
import com.mayank.lobbytransport.util.HibernateUtil;

public class DriverDaoImpl implements DriverDao {

	private Session session;
	private Criteria criteria;

	private final String subquery = "from Company where uin = ";

	public DriverDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		criteria = session.createCriteria(Driver.class);
	}

	@Override
	public void modifyDriver(Driver driver) {

		Query query = session.createQuery(subquery + driver.getDriverid());
		List<Company> ls = query.list();

		session.beginTransaction();
		session.merge(driver);
		session.getTransaction().commit();
	}

	@Override
	public void deleteDriver(int uid) {
		Query query = session.createQuery(subquery + uid);
		List<Driver> ls = query.list();

		session.beginTransaction();
		session.delete(ls.get(0));
		session.getTransaction().commit();
	}

	@Override
	public Driver getDriverbyid(int uid) {
		criteria.add(Restrictions.eq("uin", uid));

		List<Driver> ls = criteria.list();

		return ls.get(0);
	}

	@Override
	public List<Driver> getregisteredDrivers() {
		return criteria.list();
	}

}
