package com.mayank.lobbytransport.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.mayank.lobbytransport.builder.CompanyBuilder;

@Entity
public class Company  implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	private int uin ; 
	private String name ; 
	private String address ; 
    private String email ; 
    private long mobileNumber ; 
    private String state ; 
    private  String city ; 
    
    @ManyToMany
    List<Consigner> consigner ; 
    
    @ManyToMany
    List<Consignee> consignee ; 
    
	Company()
	{
		// Used by internal Hibernate Api as a Bean
	}
	
	public Company(CompanyBuilder builder){
		this.name = builder.name ; 
		this.address = builder.address ; 
		this.city = builder.city ; 
		this.state = builder.state ; 
		this.mobileNumber = builder.mobileNumber ; 
		this.email = builder.email ; 
	}

	public int getUin() {
		return uin;
	}

	public void setUin(int uin) {
		this.uin = uin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}
