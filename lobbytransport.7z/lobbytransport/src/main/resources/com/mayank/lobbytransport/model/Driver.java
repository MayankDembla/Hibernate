package com.mayank.lobbytransport.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.mayank.lobbytransport.builder.DriverBuilder;

@Entity
public class Driver {

	@Id
	private int driverid;
	private String name;
    private String address ; 
    private String city ; 
    private String state ; 
	private long mobileNumber;

	@OneToMany(mappedBy = "driver")
	private List<Vehicle> vehicles;
	

	public Driver() {
	}
	
	public Driver(DriverBuilder builder) {
		this.driverid = builder.driverid ; 
		this.name = builder.name ; 
		this.address = builder.address ;
		this.city = builder.city ; 
		this.state = builder.state ; 
		this.mobileNumber = builder.mobileNumber;
	}
	
	public int getDriverid() {
		return driverid;
	}

	public void setDriverid(int driverid) {
		this.driverid = driverid;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
    public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
