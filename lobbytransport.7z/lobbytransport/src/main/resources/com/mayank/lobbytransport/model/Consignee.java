package com.mayank.lobbytransport.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Consignee {

	@Id
	private int consigneeId ; 
	
	private String password ; 
	
	private long mobileNumber ; 
	
	// Many Consigner can sell goods to many Consignee 
	@ManyToMany(mappedBy = "listconsignee")
	private List<Consigner> Consigner ;
	
	@ManyToMany(mappedBy = "consignee")
	private List<Company> company ; 
	
	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public List<Company> getCompany() {
		return company;
	}

	public void setCompany(List<Company> company) {
		this.company = company;
	}



	public int getConsigneeId() {
		return consigneeId;
	}

	public void setConsigneeId(int consigneeId) {
		this.consigneeId = consigneeId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Consigner> getConsigner() {
		return Consigner;
	}

	public void setConsigner(List<Consigner> consigner) {
		Consigner = consigner;
	} 

	
}
