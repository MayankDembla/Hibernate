package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.model.Company;

public interface CompanyServices {
	
	void addCompany(Company company) ; 
	
	void modifyCompany(Company company) ; 
	
	void deleteCompany(int uin) ; 
	
}
