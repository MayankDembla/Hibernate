package com.mayank.lobbytransport.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Insurance {
	
	@Id
	private int insuaranceNumber ; 
	
	private String insuranceName ; 
	
	private String companyName ; 
	
	private String fromDate ; 
	
	private String expiryDate ;
	
	@OneToOne
	private Vehicle vehicle ; 
	
	public String getInsuranceName() {
		return insuranceName;
	}
	
	public int getInsuaranceNumber() {
		return insuaranceNumber;
	}

	public void setInsuaranceNumber(int insuaranceNumber) {
		this.insuaranceNumber = insuaranceNumber;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	} 

}
