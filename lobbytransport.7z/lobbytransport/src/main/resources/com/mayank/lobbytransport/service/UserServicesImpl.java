package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.dao.UserDao;
import com.mayank.lobbytransport.dao.UserDaoImpl;
import com.mayank.lobbytransport.model.User;

public class UserServicesImpl implements UserServices{

	private PersistDao pdao ;
	private UserDao udao ; 
	
	public UserServicesImpl() {
		pdao = new PersistDaoImpl() ;
		udao  = new UserDaoImpl() ; 
	}
	
	@Override
	public boolean isValidUser(String name, String password) {
		return udao.isValidUser(name, password);
	}

	@Override
	public void registerNewUser(User user) {
		pdao.register(user);
	}

	@Override
	public User getUser(String name, String password) {
		return udao.getUserByName(name , password) ; 
	}
}
