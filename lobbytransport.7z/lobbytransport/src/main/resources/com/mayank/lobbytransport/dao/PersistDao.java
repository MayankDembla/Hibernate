package com.mayank.lobbytransport.dao;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Consignee;
import com.mayank.lobbytransport.model.Consigner;
import com.mayank.lobbytransport.model.Driver;
import com.mayank.lobbytransport.model.User;
import com.mayank.lobbytransport.model.Vehicle;

public interface PersistDao {

	void register(Company company);
	
	void register(Vehicle vehicle) ; 
	
	void register(Driver driver) ; 
	
	void register(Consignee consignee) ; 
	
	void register(Consigner consignor) ; 
	
	void register(User user) ; 
	
}
