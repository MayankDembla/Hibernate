package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.model.User;

public interface UserServices {

	boolean isValidUser(String name, String password);

	void registerNewUser(User user);
	
	User getUser(String name , String password ) ; 
}
