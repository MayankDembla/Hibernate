package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Consigner;

public interface ConsignerDao {
	
	Consigner getConsigner(String name) ; 
	
	List<Consigner> getregisteredConsignor() ; 
	

}
