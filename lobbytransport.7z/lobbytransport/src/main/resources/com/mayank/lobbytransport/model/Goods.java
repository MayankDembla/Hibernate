package com.mayank.lobbytransport.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Goods {
	
	@Id
	private int goodsId ;
	
	private String name ; 
	
	private int quantity ; 
	
	private String description ;
	
	private String recepiptVoucher ; 
	
	private String loadingAdvice ;
	
	@ManyToOne
	private Consigner consigner ; 
	
	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	
	public String getRecepiptVoucher() {
		return recepiptVoucher;
	}

	public void setRecepiptVoucher(String recepiptVoucher) {
		this.recepiptVoucher = recepiptVoucher;
	}

	public String getLoadingAdvice() {
		return loadingAdvice;
	}

	public void setLoadingAdvice(String loadingAdvice) {
		this.loadingAdvice = loadingAdvice;
	}

	public Consigner getConsigner() {
		return consigner;
	}

	public void setConsigner(Consigner consigner) {
		this.consigner = consigner;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	} 

}
