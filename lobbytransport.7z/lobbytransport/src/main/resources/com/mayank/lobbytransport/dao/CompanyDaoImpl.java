package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.util.HibernateUtil;

public class CompanyDaoImpl implements CompanyDao {

	private Session session;
	private Criteria criteria;

	private final String subquery = "from Company where uin = ";

	public CompanyDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		criteria = session.createCriteria(Company.class);
	}

	@Override
	public List<Company> getregisteredCompanies() {

		return criteria.list();
	}

	@Override
	public void modifyCompany(Company company) {

		Query query = session.createQuery(subquery + company.getUin());
		List<Company> ls = query.list();

		session.beginTransaction();
		session.merge(company);
		session.getTransaction().commit();
	}

	@Override
	public void deleteCompany(int uin) {
		Query query = session.createQuery(subquery + uin);
		List<Company> ls = query.list();

		session.beginTransaction();
		session.delete(ls.get(0));
		session.getTransaction().commit();

	}

	@Override
	public Company getCompanybyUin(int uin) {

		criteria.add(Restrictions.eq("uin", uin));

		List<Company> ls = criteria.list();

		return ls.get(0);
	}

}
