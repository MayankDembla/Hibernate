package com.mayank.lobbytransport.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mayank.lobbytransport.model.CompanyBuilder;
import com.mayank.lobbytransport.service.CompanyServiceImpl;
import com.mayank.lobbytransport.service.CompanyServices;

/**
 * Servlet implementation class ComapnyServlet
 */
@WebServlet("/company-service")
public class ComapnyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CompanyServices service;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ComapnyServlet() {
		service = new CompanyServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String act = req.getParameter("ACT");

		switch (act) {
		case "add":
			CompanyBuilder builder = new CompanyBuilder(Integer.parseInt(req.getParameter("uin")))
					.name(req.getParameter("name")).address(req.getParameter("address")).city(req.getParameter("city"))
					.state(req.getParameter("state")).email(req.getParameter("email"))
					.mobile(Long.valueOf(req.getParameter("mobile")));

			service.addCompany(builder.build());
			break;

		}

	}

}
