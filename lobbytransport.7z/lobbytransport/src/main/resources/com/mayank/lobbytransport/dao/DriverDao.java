package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Driver;

public interface DriverDao {

	void modifyDriver(Driver driver);

	void deleteDriver(int uid);

	Driver getDriverbyid(int uid);

	List<Driver> getregisteredDrivers();

}
