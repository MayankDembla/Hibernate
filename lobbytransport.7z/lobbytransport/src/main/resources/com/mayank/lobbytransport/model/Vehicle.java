package com.mayank.lobbytransport.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.mayank.lobbytransport.builder.VehicleBuilder;
import com.mayank.lobbytransport.dao.DriverDao;
import com.mayank.lobbytransport.dao.DriverDaoImpl;

@Entity
public class Vehicle {
	
	@Id
	private String vehicleNo;

	private String make;

	private String vehicleType;

	private int rskm;

	private float average;

	private int cost;

	private String fueltype;

	@OneToOne(mappedBy = "vehicle")
	private Insurance insuarance;

	private String name;

	// One Driver has Many Vehicles
	@ManyToOne
	private Driver driver;

	Vehicle() {
		// Used by hibernate
	}

	public Vehicle(VehicleBuilder builder) {
		this.vehicleNo = builder.vehicleNo;
		this.name = builder.name;
		this.make = builder.make;
		this.fueltype = builder.fueltype;
		this.rskm = builder.rskm;
		this.average = builder.average;
		this.cost = builder.cost;
		this.vehicleType = builder.vehicleType;

		// Insurance
		this.insuarance.setInsuranceName(builder.insuranceName);
		this.insuarance.setCompanyName(builder.icompanyName);
		this.insuarance.setFromDate(builder.idateOfInsurance);
		this.insuarance.setExpiryDate(builder.idateOfExpiry);

		// Setting Driver
		DriverDao ddao = new DriverDaoImpl();
		this.driver = ddao.getDriverByName(builder.driverName);
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public int getRskm() {
		return rskm;
	}

	public void setRskm(int rskm) {
		this.rskm = rskm;
	}

	public float getAverage() {
		return average;
	}

	public void setAverage(float average) {
		this.average = average;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getFueltype() {
		return fueltype;
	}

	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}

	public Insurance getInsuarance() {
		return insuarance;
	}

	public void setInsuarance(Insurance insuarance) {
		this.insuarance = insuarance;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	@Override
	public String toString() {
		return "Vehicle [make=" + make + ", vehicleType=" + vehicleType + ", rskm=" + rskm + ", average=" + average
				+ ", cost=" + cost + ", fueltype=" + fueltype + ", insuarance=" + insuarance + ", name=" + name
				+ ", vehicleNo=" + vehicleNo + "]";
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}

}
