package com.mayank.lobbytransport.builder;

import com.mayank.lobbytransport.model.Vehicle;

public class VehicleBuilder {

	public String vehicleNo;
	public String name;
	public String make;
	public String fueltype;
	public int rskm;
	public float average;
	public int cost;
	public String vehicleType;
	
	public String insuranceName ; 
	public String icompanyName ; 
	public String idateOfInsurance ; 
	public String idateOfExpiry ; 
	
	public String driverName ; 

	public VehicleBuilder(String vehicleNo)
	{
		this.vehicleNo = vehicleNo ;
	}
   
    public VehicleBuilder vehicleName(String name)
    {
    	this.name = name ; 
    	return this ; 
    }
    
    public VehicleBuilder make(String make)
    {
    	this.make = make ; 
    	return this ; 
    }
    
    public VehicleBuilder fueltype(String type)
    {
    	this.fueltype = type; 
    	return this ; 
    }
   
    public VehicleBuilder rskm(int rskm)
    {
    	this.rskm = rskm ; 
    	return this ; 
    }
    
    public VehicleBuilder avergae(float average)
    {
    	this.average = average ; 
    	return this ; 
    }
    
    public VehicleBuilder cost(int cost)
    {
    	this.cost = cost ; 
    	return this ; 
    }
    
    public VehicleBuilder iName(String name) { 
    	this.insuranceName = name ; 
    	return this ; 
    }
    
    public VehicleBuilder iCompany(String name) { 
    	this.icompanyName = name ; 
    	return this ; 
    }
    
    public VehicleBuilder iDateoi(String doi) { 
    	this.idateOfInsurance = doi ; 
    	return this ; 
    }
    
    public VehicleBuilder iDateoe(String doe) { 
    	this.idateOfExpiry = doe ; 
    	return this ; 
    }
    
    public VehicleBuilder vehicleType(String type)
    {
    	this.vehicleType = type ; 
    	return this ; 
    }
    
    public VehicleBuilder driver(String name)
    {
    	this.driverName = name ; 
    	return this ; 
    }

    public Vehicle build() { 
    	Vehicle v = new Vehicle(this) ; 
    	validateVehicleObject(v) ; 
    	return v ; 
    }

    private void validateVehicleObject(Vehicle vehicle) {
        //Do some basic validations to check 
        //if user object does not break any assumption of system
    }

}
