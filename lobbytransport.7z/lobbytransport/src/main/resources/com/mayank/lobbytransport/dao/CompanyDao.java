package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Company;

public interface CompanyDao {

    void modifyCompany(Company company) ; 
    
    void deleteCompany(int uin) ; 
	
    Company getCompanybyUin(int uin) ; 
    
	List<Company> getregisteredCompanies() ; 
	
}
