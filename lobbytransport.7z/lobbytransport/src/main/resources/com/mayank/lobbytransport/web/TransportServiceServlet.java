package com.mayank.lobbytransport.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mayank.lobbytransport.service.UserServices;
import com.mayank.lobbytransport.service.UserServicesImpl;


@WebServlet("/transport-service")
public class TransportServiceServlet  extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	private static UserServices user ; 
	
	public TransportServiceServlet() {
	    user = new UserServicesImpl() ; 
	}
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		process(req,res);			
	}//doGet
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		process(req,res);			
	}//doGet
	
	private void process(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		
		String mod = req.getParameter("MOD");
		String act = req.getParameter("ACT");
		
		HttpSession session = req.getSession();
		
	    if(mod.equals("BOK")) 
		{
			switch(act)   // As Java 8 also Compares the String in Switch 
			{
			case "reg" :
				session.setAttribute("content_page","register.jsp");
				break ; 
			case "login" : 
				session.setAttribute("content_page","uLogin.jsp");
				break ; 
			case "receipt" :  // TODO
				break ; 
			case "loading" :  // TODO
				break ; 
			}
			res.sendRedirect("index.jsp");
		}	
		else if(mod.equals("VIW"))
		{
			  switch(act)
			  {
			  case "cmenu" : 
				  session.setAttribute("content_page","companymenu.jsp");
				  break ;
			  case "dmenu" : 
				  session.setAttribute("content_page","drivermenu.jsp");
				  break ; 
			  }
			  res.sendRedirect("index.jsp");
		}
		else if(mod.equals("COM"))
		{
			switch(act) {
			case "add":
				session.setAttribute("content_page","addcompany.jsp");
				break;
			case "del":
				break;
			case "mod":
				break;
			case "ret":
				break;
			}
			res.sendRedirect("index.jsp");
		}
		else if(mod.equals("DRI"))
		{
			switch(act) {
			case "add":
				session.setAttribute("content_page","driverform.jsp");
				break;
			case "del":
				break;
			case "mod":
				break;
			case "ret":
				break;
			}
			res.sendRedirect("index.jsp");
		}
	}
}
