package com.mayank.lobbytransport.builder;

import com.mayank.lobbytransport.model.User;

public class UserBuilder {

	public String name;
	public String password;
	public String address;
	public String city;
	public String state;
	public long mobileNumber;
	public String email;

	public UserBuilder(String name, String password) {
		this.name = name;
		this.password = password;
	}

	public UserBuilder address(String address) {
		this.address = address;
		return this;
	}

	public UserBuilder city(String city) {
		this.city = city;
		return this;
	}

	public UserBuilder state(String state) {
		this.state = state;
		return this;
	}

	public UserBuilder mobile(long number) {
		this.mobileNumber = number;
		return this;
	}

	public UserBuilder email(String email) {
		this.email = email;
		return this;
	}

	public User build() {
		User user = new User(this);
		validateUserObject(user);
		return user;
	}

	private void validateUserObject(User user) {
		// Do some basic validations to check
		// if user object does not break any assumption of system
	}

}
