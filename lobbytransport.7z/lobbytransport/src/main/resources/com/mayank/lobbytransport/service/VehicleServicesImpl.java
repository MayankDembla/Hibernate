package com.mayank.lobbytransport.service;

import java.util.List;

import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.dao.VehicleDao;
import com.mayank.lobbytransport.dao.VehicleDaoImpl;
import com.mayank.lobbytransport.model.Vehicle;

public class VehicleServicesImpl implements VehicleServices {
	
	PersistDao dao ; 
	VehicleDao vdao ; 
	
	public VehicleServicesImpl() {
		dao = new PersistDaoImpl() ;
		vdao = new VehicleDaoImpl() ; 
	}

	@Override
	public void registerNewVehicle(Vehicle vehicle) {
		dao.registerVehicle(vehicle);
	}

	@Override
	public Vehicle getVehicleByName(String name) {
		
		return vdao.getVehicleByName(name);
	}

	@Override
	public List<Vehicle> getregVehicles() {
		return vdao.getregisteredVehicle() ;
	}
}
