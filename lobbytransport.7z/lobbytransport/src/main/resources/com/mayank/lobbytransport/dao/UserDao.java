package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.User;

public interface UserDao {

	boolean isValidUser(String name , String password) ; 
	
	User getUserByName(String name, String password) ; 
	
	List<User> getregisteredUsers() ; 
	
	
}
