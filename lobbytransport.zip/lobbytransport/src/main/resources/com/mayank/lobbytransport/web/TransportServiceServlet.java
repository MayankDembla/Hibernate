package com.mayank.lobbytransport.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mayank.lobbytransport.service.UserServices;
import com.mayank.lobbytransport.service.UserServicesImpl;


@WebServlet("/transport-service")
public class TransportServiceServlet  extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	private static UserServices user ; 

	public TransportServiceServlet() {
		user = new UserServicesImpl() ; 
	}
	
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		process(req,res);			
	}//doGet
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		process(req,res);			
	}//doGet
	
	private void process(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException,IOException {
		
		String mod = req.getParameter("MOD");
		String act = req.getParameter("ACT");
		
		HttpSession session = req.getSession();
		
		if(mod.equals("MTN")){
			
		}
		else if(mod.equals("BOK"))
		{
			if(act.equals("Home"))
			{ 
				session.setAttribute("content_page","ucontent.jsp");
				res.sendRedirect("index.jsp");
			}
			else if(act.equals("reg"))
			{ 
				session.setAttribute("content_page","register.jsp");
				res.sendRedirect("index.jsp");
			}else if(act.equals("login")){
				session.setAttribute("content_page","uLogin.jsp");
				res.sendRedirect("index.jsp");
			}
		}	
	}
}
