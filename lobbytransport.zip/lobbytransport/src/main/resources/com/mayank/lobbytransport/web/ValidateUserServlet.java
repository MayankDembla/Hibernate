package com.mayank.lobbytransport.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mayank.lobbytransport.service.UserServices;
import com.mayank.lobbytransport.service.UserServicesImpl;

/**
 * Servlet implementation class ValidateUser
 */
@WebServlet("/validate-user")
public class ValidateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static UserServices user ;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateUserServlet() {
    	user = new UserServicesImpl() ; 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String act = req.getParameter("ACT");
		
		HttpSession session = req.getSession();
		
		if(act.equals("doLog"))    // Login USer 
		{
			String userName = req.getParameter("Username") ; 
			
			if(user.isValidUser(userName, req.getParameter("Password"))) {
				session.setAttribute("u_name",userName);
				session.setAttribute("content_page","ucontent.jsp");
				res.sendRedirect("index.jsp");
			} else {
				session.setAttribute("content_page","logFail.jsp");
				res.sendRedirect("index.jsp");
			}
	    } else if(act.equals("doReg"))  // Register User 
	    {
	    	user.registerNewUser(req.getParameter("username"),
	    			             req.getParameter("password"), 
	    			             req.getParameter("address") , 
	    			             req.getParameter("city"), 
	    			             req.getParameter("state"), 
	    			             Long.valueOf(req.getParameter("mbno")),
	    			             req.getParameter("email"));
	    	
	    	session.setAttribute("content_page","register.jsp");
	    	res.sendRedirect("index.jsp?msg=1");
	    }
		
		
	}



}
