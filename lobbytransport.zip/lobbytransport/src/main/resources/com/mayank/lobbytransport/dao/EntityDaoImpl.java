package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.User;
import com.mayank.lobbytransport.util.HibernateUtil;

public class EntityDaoImpl implements EntityDao {

	private Session session;

	public EntityDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
	}
	
	@Override
	public User getUserbyName(String name)
	{
		User user = null ; 
		
		Criteria criteria = session.createCriteria(User.class) ; 
		criteria.add(Restrictions.eq("name", name)) ; 
		
		List<User> listuser = criteria.list() ; 
			
		if(!listuser.isEmpty())
			user = (User) listuser.get(0) ; 
		
		return user ; 
	}

}
