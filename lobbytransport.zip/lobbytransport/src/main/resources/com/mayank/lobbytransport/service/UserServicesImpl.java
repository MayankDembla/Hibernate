package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.dao.EntityDao;
import com.mayank.lobbytransport.dao.EntityDaoImpl;
import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.model.User;

public class UserServicesImpl implements UserServices{

	private EntityDao dao ; 
	private PersistDao pdao ; 
	
	public UserServicesImpl() {
		dao = new EntityDaoImpl() ;
		pdao = new PersistDaoImpl() ; 
	}

	@Override
	public boolean isValidUser(String name, String password) {
		
		User user = null ; 
		// Since Name is a Primary Key 
        try {		
              user = dao.getUserbyName(name) ; 
        } catch(NullPointerException exp ) {
        	 return false ; 
        }
        
		if(user.getPassword().equals(password))
			return true ; 
		
		return false;
	}

	@Override
	public void registerNewUser(String name, String password, String address, String city, String state,
			long mobileNumber, String email) {
		
		User user = new User() ; 
		
		user.setName(name);
		user.setPassword(password);
		user.setAddress(address);
		user.setCity(city);
		user.setState(state);
		user.setEmail(email);
		user.setMobileNumber(mobileNumber);
		
		pdao.registerUser(user);
	}

   

}
