package com.mayank.lobbytransport.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.mayank.lobbytransport.model.User;
import com.mayank.lobbytransport.util.HibernateUtil;

public class PersistDaoImpl implements PersistDao {

	private Transaction transaction;

	private Session session;

	public PersistDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		transaction = session.beginTransaction();
	}

	@Override
	public void registerUser(User user) {

		try {
			session.save(user);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

}
