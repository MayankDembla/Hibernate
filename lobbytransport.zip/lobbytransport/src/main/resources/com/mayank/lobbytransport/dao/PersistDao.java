package com.mayank.lobbytransport.dao;

import com.mayank.lobbytransport.model.User;

public interface PersistDao {

	void registerUser(User user);

}
