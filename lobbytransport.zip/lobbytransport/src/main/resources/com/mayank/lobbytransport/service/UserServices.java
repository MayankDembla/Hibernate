package com.mayank.lobbytransport.service;

public interface UserServices {

	boolean isValidUser(String name, String password);

	void registerNewUser(String name, String password, 
			              String address, String city, 
			                 String state, long mobileNumber,
			                       String email);
}
