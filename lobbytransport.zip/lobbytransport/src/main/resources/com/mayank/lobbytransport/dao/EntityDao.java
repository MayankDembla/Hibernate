package com.mayank.lobbytransport.dao;

import com.mayank.lobbytransport.model.User;

public interface EntityDao {
	
	User getUserbyName(String name) ;
	
}
